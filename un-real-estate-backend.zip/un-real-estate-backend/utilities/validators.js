const validateName = (name) => {
  return true;
};

const validateUsername = (username) => {
  return true;
};

const validateMobileNo = (mobileNo) => {
  return true;
};

const validateEmail = (emailId) => {
  return true;
};

const validateRole = (role) => {
  return true;
};

const validateGender = (gender) => {
  return true;
};

const validatePassword = (password) => {
  return true;
};

module.exports = {
  validateName,
  validateUsername,
  validateMobileNo,
  validateEmail,
  validateRole,
  validateGender,
  validatePassword,
};
