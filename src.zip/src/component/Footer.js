const Footer=()=>{
return <>
<div className="container-fluid footer bg-dark text-center">
    <p className="fp">Copyright @ 2020, WeCare Allright reserved</p>
</div>

 </>
};export default Footer;
