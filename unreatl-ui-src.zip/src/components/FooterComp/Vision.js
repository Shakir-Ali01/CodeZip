import React from "react";

function Vision() {
  return (
    <div className="container my-5">
      Vision
      <br></br>
      The Vision of UnrealEstate is "Revolutionize the rental property market by
      providing a seamless online platform that offers unparalleled
      post-view-rental experience, empowering renters to make informed decisions
      and property owners to connect with effortlessly with qualified
      teanets/agents and vice-versa".
      <br></br>
      This vision highlights the company's goals of innovation user-friendly and
      bridging the gap between renters,agents and property owners
    </div>
  );
}

export default Vision;
