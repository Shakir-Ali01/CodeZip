package com.example.asmnt.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.config.Task;
import org.springframework.stereotype.Service;

import com.example.asmnt.Dtos.TaskDto;
import com.example.asmnt.controller.Task.Entity.TaskEntity;
import com.example.asmnt.exception.ResourceNotFoundException;
import com.example.asmnt.repo.TaskRepos;
@Service
public class TaskServiceImpl implements TaskService{

	@Autowired
	private TaskRepos taskrepo;

	@Override
	public TaskDto createTask(TaskDto task) {
		// TODO Auto-generated method stub
	    LocalDateTime getDateObject = LocalDateTime.now();
	    DateTimeFormatter getFormateObject = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
	    String currentFormattedDate = getDateObject.format(getFormateObject);
	   
		TaskEntity taskEntity=new TaskEntity();
		taskEntity.setCreatedAt(currentFormattedDate);
		taskEntity.setUpdatedAt(currentFormattedDate);
		taskEntity.setTitle(task.getTitle());
		taskEntity.setDescription(task.getDescription());
		taskEntity.setDueDate(task.getDueDate());
		
//		save data into database
		taskEntity= taskrepo.save(taskEntity);
		task.setId(taskEntity.getId());
		task.setCreatedAt(taskEntity.getCreatedAt());
		task.setUpdatedAt(taskEntity.getUpdatedAt());
		return task;
	}

	@Override
	public List<TaskDto> getAllTask() throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		List<TaskEntity> tList = taskrepo.findAll();
	    if(tList.isEmpty()) {
	    	throw new ResourceNotFoundException("Task Not Found");
	    }
		List<TaskDto> taskList = new ArrayList<>();
		tList.forEach(task -> {
			TaskDto singleTask = new TaskDto();
			singleTask.setCreatedAt(task.getCreatedAt());
			singleTask.setDescription(task.getDescription());
			singleTask.setDueDate(task.getDueDate());
			singleTask.setTitle(task.getTitle());
			singleTask.setId(task.getId());	
			singleTask.setUpdatedAt(task.getUpdatedAt());
			taskList.add(singleTask);
		});
		
		return taskList;
		
	}

	@Override
	public TaskDto updateTask(Long id, TaskDto taskDetails) throws ResourceNotFoundException{
		// TODO Auto-generated method stub		
		Optional getTaskEntity =taskrepo.findById(id);
        if(getTaskEntity.isEmpty()) {
			throw new ResourceNotFoundException("Task Not Found With Given Id  "+ id);
		}
		TaskEntity tEntity=(TaskEntity) getTaskEntity.get();
//		Set value in Entity For updating 
		 LocalDateTime getDateObject = LocalDateTime.now();
		    DateTimeFormatter getFormateObject = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
		    String currentFormattedDate = getDateObject.format(getFormateObject);
		tEntity.setDescription(taskDetails.getDescription());
		tEntity.setDueDate(taskDetails.getDueDate());
		tEntity.setTitle(taskDetails.getTitle());
		tEntity.setUpdatedAt(currentFormattedDate);
		
		 tEntity=taskrepo.save(tEntity);
//		Return updated TASK
		 taskDetails.setUpdatedAt(tEntity.getUpdatedAt());
		 taskDetails.setCreatedAt(tEntity.getCreatedAt());
		 taskDetails.setId(tEntity.getId());
		 return taskDetails;
		 
	}

}
