package com.example.asmnt.service;

import java.util.List;

import org.springframework.scheduling.config.Task;

import com.example.asmnt.Dtos.TaskDto;

public interface TaskService {
	public TaskDto createTask(TaskDto task);
	public List<TaskDto> getAllTask();
	public TaskDto updateTask(Long id,TaskDto taskDetails);
}
