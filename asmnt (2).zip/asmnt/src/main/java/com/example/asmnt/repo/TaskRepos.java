package com.example.asmnt.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.asmnt.controller.Task.Entity.TaskEntity;

public interface TaskRepos extends CrudRepository<TaskEntity, Long>{
	List<TaskEntity> findAll();
}
