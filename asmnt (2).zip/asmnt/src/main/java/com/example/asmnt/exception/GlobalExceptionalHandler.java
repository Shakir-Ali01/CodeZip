package com.example.asmnt.exception;
import com.example.asmnt.payload.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;



@RestControllerAdvice
public class GlobalExceptionalHandler {
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ApiResponse> handlerResourceNotFoundException(ResourceNotFoundException ex)
	{
		String message=ex.getMessage();
		ApiResponse apiResponse= new ApiResponse();
         apiResponse.setMessage(message);
         apiResponse.setStatus(HttpStatus.NOT_FOUND);

         apiResponse.setSuccess(true);
         return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
//	ApiResponse response=ApiResponse.apiResponseer().message(message).success(true).status(HttpStatus.NOT_FOUND);
	}

}
