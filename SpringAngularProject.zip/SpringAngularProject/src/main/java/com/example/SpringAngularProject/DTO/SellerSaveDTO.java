package com.example.SpringAngularProject.DTO;

public class SellerSaveDTO {
 private String sellerName;
 private String sellerEmail;
 private int sellerPasssword;
public String getSellerName() {
	return sellerName;
}
public void setSellerName(String sellerName) {
	this.sellerName = sellerName;
}
public String getSellerEmail() {
	return sellerEmail;
}
public void setSellerEmail(String sellerEmail) {
	this.sellerEmail = sellerEmail;
}
public int getSellerPasssword() {
	return sellerPasssword;
}
public void setSellerPasssword(int sellerPasssword) {
	this.sellerPasssword = sellerPasssword;
}
public SellerSaveDTO(String sellerName, String sellerEmail, int sellerPasssword) {
	super();
	this.sellerName = sellerName;
	this.sellerEmail = sellerEmail;
	this.sellerPasssword = sellerPasssword;
}
@Override
public String toString() {
	return "SellerSaveDTO [sellerName=" + sellerName + ", sellerEmail=" + sellerEmail + ", sellerPasssword="
			+ sellerPasssword + "]";
}

 
}
