package com.example.SpringAngularProject.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringAngularProject.DTO.SellerSaveDTO;
import com.example.SpringAngularProject.Entity.Seller;
import com.example.SpringAngularProject.Repository.SellerRepo;

@Service
public class sellerServiceImpl implements sellerService{

	@Autowired
	 private SellerRepo sellerRepo;
	@Override
	public String addEmployee(SellerSaveDTO sellerSaveDTO) {
		Seller checkSellerAlreadyPresent=sellerRepo.findBySellerEmail(sellerSaveDTO.getSellerEmail());
		if(checkSellerAlreadyPresent!=null)
		{
			return "This Email Already Exist.Register From Another Email Address";	
		}else {
		    	 Seller sellerEntity=new Seller(sellerSaveDTO.getSellerName(),sellerSaveDTO.getSellerEmail(),sellerSaveDTO.getSellerPasssword() );
		    	 sellerRepo.save(sellerEntity);
		    	 return "Registration Successfully for This Email"+sellerEntity.getSellerEmail();
		}

	} 

}
