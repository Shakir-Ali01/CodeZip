package com.example.SpringAngularProject.DTO;

public class EmployeeSaveDTO {

	private String employeeName;
	private String employeeAddress;
	private int mobile;
	public EmployeeSaveDTO(String employeeName, String employeeAddress, int mobile) {
		super();
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.mobile = mobile;
	}
	public EmployeeSaveDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeAddress() {
		return employeeAddress;
	}
	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}

}
