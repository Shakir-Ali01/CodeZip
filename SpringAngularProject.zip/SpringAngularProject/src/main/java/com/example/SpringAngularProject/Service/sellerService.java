package com.example.SpringAngularProject.Service;

import com.example.SpringAngularProject.DTO.EmployeeSaveDTO;
import com.example.SpringAngularProject.DTO.SellerSaveDTO;

public interface sellerService {
	String addEmployee(SellerSaveDTO sellerSaveDTO);

}
