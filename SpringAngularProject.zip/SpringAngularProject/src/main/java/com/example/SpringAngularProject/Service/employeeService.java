package com.example.SpringAngularProject.Service;

import com.example.SpringAngularProject.DTO.EmployeeSaveDTO;

public interface employeeService {
	String addEmployee(EmployeeSaveDTO employeeSaveDTO);
}
