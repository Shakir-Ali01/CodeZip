package com.example.SpringAngularProject.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {
@Id
@Column(name="employee_id",length=50)
@GeneratedValue(strategy = GenerationType.AUTO)
private int employeeId;
@Column(name="employee_name",length=50)
private String employeeName;
@Column(name="employee_address",length=90)
private String employeeAddress;
@Column(name="mobile",length=50)
private int mobile;
public Employee(int employeeId, String employeeName, String employeeAddress, int mobile) {
	super();
	this.employeeId = employeeId;
	this.employeeName = employeeName;
	this.employeeAddress = employeeAddress;
	this.mobile = mobile;
}
public Employee(String employeeName, String employeeAddress, int mobile) {
	super();
	this.employeeId = employeeId;
	this.employeeName = employeeName;
	this.employeeAddress = employeeAddress;
	this.mobile = mobile;
}
public Employee() {
	super();
}
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public String getEmployeeAddress() {
	return employeeAddress;
}
public void setEmployeeAddress(String employeeAddress) {
	this.employeeAddress = employeeAddress;
}
public int getMobile() {
	return mobile;
}
public void setMobile(int mobile) {
	this.mobile = mobile;
}
@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAddress="
			+ employeeAddress + ", mobile=" + mobile + "]";
}


}
