package com.example.SpringAngularProject.DTO;

public class EmployeeUpdateDTO {
	private int employeeId;
	private String employeeName;
	private String employeeAddress;
	private int mobile;
	public EmployeeUpdateDTO(int employeeId, String employeeName, String employeeAddress, int mobile) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.mobile = mobile;
	}
	public EmployeeUpdateDTO() {
		super();
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeAddress() {
		return employeeAddress;
	}
	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "EmployeeUpdateDTO [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAddress="
				+ employeeAddress + ", mobile=" + mobile + "]";
	}
	
}
