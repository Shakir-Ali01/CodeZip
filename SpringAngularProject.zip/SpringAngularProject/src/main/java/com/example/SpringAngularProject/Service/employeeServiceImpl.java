package com.example.SpringAngularProject.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringAngularProject.DTO.EmployeeDTO;
import com.example.SpringAngularProject.DTO.EmployeeSaveDTO;
import com.example.SpringAngularProject.DTO.EmployeeUpdateDTO;
import com.example.SpringAngularProject.Entity.Employee;
import com.example.SpringAngularProject.Repository.EmployeeRepo;
@Service
public class employeeServiceImpl implements employeeService{

	@Autowired
	 private EmployeeRepo empRepository;
	@Override
	public String addEmployee(EmployeeSaveDTO employeeSaveDTO) {
		// TODO Auto-generated method stub
		Employee employee=new Employee
		(employeeSaveDTO.getEmployeeName(),employeeSaveDTO.getEmployeeAddress(),
		 employeeSaveDTO.getMobile());
		empRepository.save(employee);
		return employee.getEmployeeName();
	}
	public List<EmployeeDTO> getAllEmployee() {
		// TODO Auto-generated method stub
		List<Employee> getEmployees=empRepository.findAll();
		List<EmployeeDTO> employeeDTOList=new ArrayList<>();
		for(Employee e: getEmployees)
		{
			EmployeeDTO employeeDTO=new EmployeeDTO(
					e.getEmployeeId(),e.getEmployeeName(),e.getEmployeeAddress(),e.getMobile()
					);
			employeeDTOList.add(employeeDTO);
		}
		return employeeDTOList;
	}
	
	public String updateEmployee(EmployeeUpdateDTO employeeUpdateDTO) {
		// TODO Auto-generated method stub
		if(empRepository.existsById(employeeUpdateDTO.getEmployeeId()))
		{
			Employee employee=empRepository.getById(employeeUpdateDTO.getEmployeeId());
			employee.setEmployeeName(employeeUpdateDTO.getEmployeeName());
			employee.setEmployeeAddress(employeeUpdateDTO.getEmployeeAddress());
			employee.setMobile(employeeUpdateDTO.getMobile());
			 empRepository.save(employee);
			 return employee.getEmployeeName();
			 
		}else{
			return "Employee Id Not Found";
		}
		
		
	}
	public boolean deleteEmployee(int id) {
		// TODO Auto-generated method stub
		if(empRepository.existsById(id))
		{
			empRepository.deleteById(id);
			return true;
		}
		else{
			return false;
		}
		
	}
}
