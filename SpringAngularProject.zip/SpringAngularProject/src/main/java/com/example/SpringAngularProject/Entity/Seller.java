package com.example.SpringAngularProject.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seller")
public class Seller {

@Id
@Column(name="seller_id",length=50)
@GeneratedValue(strategy = GenerationType.AUTO)
private int Id;
@Column(name="seller_name",length=50)
private String sellerName;
@Column(name="seller_email",length=50)
private String sellerEmail;
@Column(name="seller_password",length=50)
private int sellerPasssword;
public int getId() {
	return Id;
}
public Seller(int id, String sellerName, String sellerEmail, int sellerPasssword) {
	super();
	Id = id;
	this.sellerName = sellerName;
	this.sellerEmail = sellerEmail;
	this.sellerPasssword = sellerPasssword;
}
public String getSellerEmail() {
	return sellerEmail;
}
public void setSellerEmail(String sellerEmail) {
	this.sellerEmail = sellerEmail;
}
public void setId(int id) {
	Id = id;
}
public String getSellerName() {
	return sellerName;
}
public void setSellerName(String sellerName) {
	this.sellerName = sellerName;
}
public int getSellerPasssword() {
	return sellerPasssword;
}
public void setSellerPasssword(int sellerPasssword) {
	this.sellerPasssword = sellerPasssword;
}

public Seller(String sellerName, String sellerEmail, int sellerPasssword) {
	super();
	this.sellerName = sellerName;
	this.sellerEmail = sellerEmail;
	this.sellerPasssword = sellerPasssword;
}
public Seller() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Seller [Id=" + Id + ", sellerName=" + sellerName + ", sellerEmail=" + sellerEmail + ", sellerPasssword="
			+ sellerPasssword + "]";
}




}
