package com.example.asmnt.service;

import java.util.List;

import org.springframework.scheduling.config.Task;

public interface TaskService {
	public Task createTask(Task task);
	public List<Task> getAllTask();
	public Task updateTask(Long id,Task taskDetails);
}
