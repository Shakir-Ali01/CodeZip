package com.example.asmnt.service;

import java.util.List;
import org.springframework.scheduling.config.Task;
import org.springframework.stereotype.Service;



@Service
public class TaskServiceImpl implements TaskService{


	@Override
	public Task createTask(Task task) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Task> getAllTask() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Task updateTask(Long id, Task taskDetails) {
		// TODO Auto-generated method stub
		return null;
	}

}
