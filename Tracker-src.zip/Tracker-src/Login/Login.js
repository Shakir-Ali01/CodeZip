import { useState } from "react";
import { Link, Outlet} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from "react-router-dom";
import axios from "axios";
const Login = () => {
    // start get user info if has correct credentials
    const fetchData = () => {
        axios
          .get("http://localhost:8089/DefectTracker/"+data.username+"/"+data.password)
          .then((res) => {
            setUserInfo(res.data);
            if(res.data)
            {
               localStorage.setItem('user', JSON.stringify(res.data.name));
               //set value into local storage
               localStorage.setItem('isTester', JSON.stringify(res.data.isTester))
               //console.log(res.data.isTester);
               //getting value from local storage
               //console.log(JSON.parse(localStorage.getItem('user')));
              navigate("dashboard");
            }
          })
          .catch((err) => {
            console.log(err);
          });
      };
    //end
let navigate = useNavigate();
  const [status, setStatus] = useState(null);
  const[userInfo, setUserInfo]=useState({
    userId: "",
    name: "",
    password: "",
    isTester: ""
});
  const[data,setData] = useState({
    username: "",
    password:""
  });
  const handleSubmit = (event) => {
    event.preventDefault();
    if (!data.username || !data.password) {
      setStatus(false);
    } else {
      setStatus(true);
       fetchData();
       // if(userInfo.name)
       // {
       //    navigate("dashboard")
       // }


      //{state:{id:1,name:'sabaoon'}}


    }
  };
 const handleChange =(event) =>{
     let { name, value } = event.target;
    setData({ ...data, [name]: value })
 }
 return (
    <>

      <div className="container-fluid">
      <div className="row">
        <div className="col-md-4">
        </div>
        <div className="col-md-4 border mt-5 p-0">
        <div className="panel panel-default">
          <div className="panel-heading text-center">
            <h4 className="pb-4" >Defect Tracker</h4>
            <p className="text-white m-0" style={{background:'#4787be'}}>Login</p>
          </div>
          <div className="panel-body" style={{backgroundColor:"#efefef"}}>

            <div className="mx-3 border border-1  mb" style={{backgroundColor:"#efefef"}}>
    <div>
    <form onSubmit={handleSubmit}>
    <div class="mx-1 mb-2 mt-2 row">
    <label for="staticEmail" class="col-sm-2 col-form-label"><span className='fw-bold' style={{fontSize:'10px'}}>UserName</span></label>
    <div class="col-sm-10">
      <input type="text" placeholder="Enter UserName"   name = "username" onChange={handleChange} class="form-control" id="staticEmail" />
    </div>
  </div>
  <div class="mx-1 mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label"><span className='fw-bold' style={{fontSize:'10px'}}>Password</span></label>
    <div class="col-sm-10">
      <input type="password"  name = "password" class="form-control"  onChange={handleChange} placeholder="Enter Password" id="inputPassword"/>
    </div>
  </div>
  <div className="text-center mb-1"><input type="submit"  className="lh-base" style={{fontFamily:'none'}} value="Sign in"/></div>
  {status === false && <div className="text-danger text-center">Enter {data.username===''?'UserName':'Password'}</div>}
  {status === true && <div className="text-danger text-center">Wrong Credentials</div>}
   </form>

    </div>

            </div>
          </div>
        </div>
          {/* <div>
            <h4 className="pb-5 text-center">Defect Tracker</h4>
          </div>
          <div>
            <p className="bg-primary text-center p-1 text-white font-weight-bold" >Login</p>
          </div> */}
        {/* <form onSubmit={handleSubmit}>
          <div className="form-group">
            <div className="col-lg-6">
            <label htmlFor="name" >Username:</label>
            <input
              style={{ width: "40%" }}
              type="text"
              id="username"
              name = "username"
              value={data.username}
              onChange={handleChange}
              className="form-control"
              placeholder="Enter Name"
            />
          </div></div>
          <div className="form-group">
            <label htmlFor="pwd">Password:</label>
            <input
              style={{ width: "40%" }}
              type="password"
              id="password"
              name = "password"
              value={data.password}
              onChange={handleChange}
              className="form-control"
              placeholder="Enter password"
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Login
          </button>
          {status === false && <div className="text-error">Enter User Name and Password</div>}
          {status === true && <div className="text-success">Login Successful</div>}
        </form> */}
      </div>
      <div className="col-md-4">
      </div>
      </div>
      </div>
    </>
  );
};
export default Login;
