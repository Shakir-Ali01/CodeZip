import React from 'react'
import { useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate , Link} from "react-router-dom";
import axios from "axios";
const AddDefect = () => {
    let navigate = useNavigate();
    const [status, setStatus] = useState(null);
    const[data,setData] = useState({
      category: "",
      description: "",
      priority: "",
      status:"open"
    });
    const handleSubmit = (event) => {
      event.preventDefault();
      if (!data.category || !data.description || !data.priority) {
        setStatus(false);
      } else {
        setStatus(true);
        console.log(data)
        axios
      .post("http://localhost:8089/DefectTracker", data)
      .then((response) => {
        setData("");
        console.log(response.data);
        alert("success");
        navigate('/dashboard');
      })
      .catch((err) => {
        console.log("Cant post");
      });
        //navigate("/dashboard")

      }
    };
   const handleChange =(event) =>{
       let { name, value } = event.target;
      setData({ ...data, [name]: value })
   }
   function logOut()
   {
     localStorage.clear();
     navigate('/');
   }
  return (
    <div className="container-fluid" style={{fontFamily:'sans-serif'}}>
    <div className="row">
      <div className="col-md-4">
      </div>
      <div className="col-md-4 border mt-5 p-0">
      <div className="panel panel-default">
        <div className="panel-heading text-center">
          <h4 className="pb-1 pt-1" >Defect Tracker</h4>
          {/* start */}
          <div className='pb-3'>
          <span className='text-center logout' style={{color:'#4787be',fontSize:'12px',fontWeight:'500'}} onClick={logOut}>
           Logout</span><br></br>
           <Link to="/adddefect" style={{textDecoration:'none'}}>
            <span className='text-center mt-0 pt-0'  style={{color:'#4787be',fontSize:'12px',fontWeight:'500'}}>
              <button className="lh-base  p-1 px-2 rounded-1" style={{fontFamily:'none',backgroundColor:'#286090',border:'none',color:'#fff'}}>Add Defect</button>
            </span>
          </Link>
          &nbsp;&nbsp;
          <Link to="/dashboard" style={{textDecoration:'none'}}>
          <span className='text-center mt-0 pt-0' style={{color:'#4787be',fontSize:'12px',fontWeight:'500'}}>
            <button className="lh-base bgc p-1 px-2 rounded-1" style={{fontFamily:'none',border:'none',color:'#fff'}}>View Defects</button>
          </span></Link>
          </div>
          {/* End  */}
          <p className="text-white m-0 p-1" style={{background:'#4787be',fontWeight:'400'}}>Add Defects</p>
        </div>
        <div className="panel-body pb-3 pt-3" style={{backgroundColor:"#efefef"}}>

<div className="mx-3 mt-2 border border-1 rounded" style={{backgroundColor:"#efefef"}}>
  <div>
  <form onSubmit={handleSubmit}>
  <div class="mx-1 mb-2 mt-2 row">
  <label for="staticEmail" class="col-sm-2 col-form-label"><span className='fw-bold' style={{fontSize:'10px'}}>Defect Category</span></label>
  <div class="col-sm-10">
    {/* <input type="text" placeholder="Enter UserName"   name = "username" onChange={handleChange} class="form-control" id="staticEmail" /> */}
    <select className='form-select' name = "category" onChange={handleChange}>
        <option disabled selected value>Select</option>
        <option >UI</option>
          <option >Functional</option>
            <option >Change Request</option>
    </select>
  </div>
  {status === false && <span className="text-danger text-center">
  {data.category===''?'Please Select Category':''}</span>}
</div>
<div class="mx-1 mb-3 row">
  <label for="inputPassword" class="col-sm-2 col-form-label"><span className='fw-bold' style={{fontSize:'10px'}}>Description</span></label>
  <div class="col-sm-10">
    {/* <input type="password"  name = "password" class="form-control"  onChange={handleChange} placeholder="Enter Password" id="inputPassword"/> */}
    <textarea class="form-control"  name = "description"  onChange={handleChange} placeholder="Enter Description" aria-label="With textarea"></textarea>
  </div>
  {status === false && <div className="text-danger text-center">
  {data.description===''?'Please Enter Description':''}</div>}
</div>
<div class="mx-1 mb-3 row">
  <label for="inputPassword" class="col-sm-2 col-form-label"><span className='fw-bold' style={{fontSize:'10px'}}>Priority</span></label>
  <div class="col-sm-10">
    <input type="text"  name ="priority" class="form-control"  onChange={handleChange} placeholder="Enter Priority" id="inputPassword"/>
  </div>
  {status === false && <span className="text-danger text-center">
  {data.priority===''?'Please Enter  Priority':''}</span>}
</div>
<div className="text-center mb-3">
    <input type="submit"  className="lh-base bgc p-1 px-2 rounded-1" style={{fontFamily:'none',border:'none',color:'#fff'}} value="Add Defect"/>
</div>
{/* {status === false && <div className="text-danger text-center">Enter
{data.username===''?'UserName':'Password'}
</div>} */}

 </form>

  </div>

          </div>
        </div>
      </div>
        {/* <div>
          <h4 className="pb-5 text-center">Defect Tracker</h4>
        </div>
        <div>
          <p className="bg-primary text-center p-1 text-white font-weight-bold" >Login</p>
        </div> */}
      {/* <form onSubmit={handleSubmit}>
        <div className="form-group">
          <div className="col-lg-6">
          <label htmlFor="name" >Username:</label>
          <input
            style={{ width: "40%" }}
            type="text"
            id="username"
            name = "username"
            value={data.username}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter Name"
          />
        </div></div>
        <div className="form-group">
          <label htmlFor="pwd">Password:</label>
          <input
            style={{ width: "40%" }}
            type="password"
            id="password"
            name = "password"
            value={data.password}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter password"
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Login
        </button>
        {status === false && <div className="text-error">Enter User Name and Password</div>}
        {status === true && <div className="text-success">Login Successful</div>}
      </form> */}
    </div>
    <div className="col-md-4">
    </div>
    </div>
    </div>
  )
}

export default AddDefect;
