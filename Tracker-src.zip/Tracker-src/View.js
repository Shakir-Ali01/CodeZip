import React, { useEffect, useState } from "react";
import axios from "axios";
import './App.css';
import { Link } from 'react-router-dom';
import { useNavigate } from "react-router-dom";
const View = () => {
  const [categoryFilter, setCategoryFilter]=useState(0);
  const [priorityFilter, setPrioritFilter]=useState(0);
  var priority;
  var cat;

  //start filter the data of view
  const valueForFiltering =(event) =>{
      let value= event.target.value;
      var catValue = document.getElementById('fil').value;
      var priorityValue = document.getElementById('prio').value;
      if(catValue=="All" && priorityValue=="All"){
        fetchData();
      }
      else{
        if(catValue=="All")
        {
          catValue='';
        }
        if(priorityValue=="All"){
          priorityValue='';
        }
        axios
          .get("http://localhost:8089/DefectTracker/getAllDefect/"+priorityValue+"/"+catValue)
          .then((res) => {
            console.log(res);
            setDefect(res.data);
            console.log(allDefect);
          })
          .catch((err) => {
            console.log(err);
          });
      }


  }
  //End filter the data of view
  //update the status of defects
  const updateStatus = (value)=>{
    axios
     .put("http://localhost:8089/DefectTracker/" + value)
     .then((res) => {
       alert("Status updated successfully")
         fetchData();
       console.log(res);
     })
     .catch((err) => {
       console.log(err);
     });
  }
  //getting value from localStorage
  const user=JSON.parse(localStorage.getItem('isTester'));
  let navigate = useNavigate();
  const [allDefect, setDefect] = useState([]);
  function logOut()
  {
    localStorage.clear();
    navigate('/');
  }
  const fetchData = () => {
  axios
    .get("http://localhost:8089/DefectTracker/getAllDefect")
    .then((res) => {
      console.log(res);
      setDefect(res.data);
      console.log(allDefect);
    })
    .catch((err) => {
      console.log(err);
    });
};
  useEffect(() => {
    fetchData();
  }, []);
  return (
    <div className="container-fluid" style={{fontFamily:'sans-serif'}}>
    <div className="row">
      <div className="col-md-2">
      </div>
      <div className="col-md-8 border mt-5 p-0">
      <div className="panel panel-default">
        <div className="panel-heading text-center">
          <h4 className="pb-2" >Defect Tracker </h4>
          <span className='text-center logout' onClick={logOut}>Logout</span><br></br>
              {JSON.parse(localStorage.getItem('isTester'))=== "1" ?<div><Link to="/adddefect" className="lnk">
              <span className="text-center mt-0 pt-0 add-defect">Add Defect</span></Link>
              <span className="text-center mt-0 pt-0 view-defect">View Defect</span></div> :''
                }
        </div>
        <div className="panel-body">
          {/* Filter Area */}
          <div className="mx-3 pb-3 mt-2 border border-1 text-center" >
              <h5 className="pt-2 pb-2" >Filter Details</h5>
              <label style={{color:'black',fontSize:'12px',fontWeight:'700'}}>Priority&nbsp;&nbsp;</label>
              <select onChange={valueForFiltering} name="priority" id="prio">
                <option selected > All</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
              </select>
              <div className='pt-3'>
              <label style={{color:'black',fontSize:'12px',fontWeight:'700'}}>Category&nbsp;&nbsp;</label>
              <select style={{width:'140px'}} id="fil" onChange={valueForFiltering}>
                <option selected > All</option>
                <option>Functional</option>
                <option>UI</option>
                <option>Change Request</option>
              </select>
              </div>

          <div>


              </div>

          </div>
          {/* Defect Details */}
          <div className='text-center pt-2'>
              <span style={{fontSize:'20px',fontWeight:'500'}}>Defect Details</span><br/>
              <span className='text-danger' style={{fontSize:'11px',fontWeight:'700'}}>Search Results: {allDefect.length}</span>
          </div>
          {/* Table Section */}
            <div className='mx-3 text-center tbl'>
                <table className="table table-bordered">
                 <thead>
                     <tr className="trbg" style={{background:'#4787be'}} >
                        <th className='bgc'>Defect <br/>Category</th>
                        <th className='bgc'>Description</th>
                        <th className='bgc'>Priority</th>
                        <th className='bgc'>Status</th>
                        <th className='bgc'>Change Status</th>
                     </tr>
                 </thead>
                 <tbody className='table-secondary border-white'>
                 {allDefect!=='' &&
                 allDefect.map((defectValue) => {
                 return (
                    <tr>
                        <td>{defectValue.category}</td>
                        <td>{defectValue.description}</td>
                        <td>{defectValue.priority}</td>
                        <td>{defectValue.status}</td>
                        {defectValue.status==="open"?<td className='bgc-text'   onClick={(event)=> {updateStatus(defectValue.id)}} >close defect</td>:
                        <td className='text-secondary'>No Action Pending</td>}

                    </tr>
                  );
                })
              }
                 {allDefect=='' && <tr><td colspan="5">Data Not Found</td></tr>}
                 </tbody>
                </table>
            </div>
          {/* End Table Section */}
        </div>
      </div>

    </div>
    <div className="col-md-2">
    </div>
    </div>
    </div>

  )
}

export default View;
